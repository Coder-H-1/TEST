import javax.swing.*;
import java.awt.*;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchEvent;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.Timer;
import java.util.TimerTask;

public class Updater_main extends JFrame {

    private JTextArea textArea;
    private Timer timer;
    private String filePath = "System_files\\File.txt";
    private int delay = 100; // Milliseconds between updates

    public Updater_main() {
        setTitle("Lucas: Learning Universal Computing and Assistance System");
        setSize(700, 250); // Set the size to 500x500
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Make the window non-resizable
        setResizable(false);

        textArea = new JTextArea();
        textArea.setEditable(false);

        // Set font to "Roboto Mono" with size 14
        Font font = new Font("Roboto Mono", Font.PLAIN, 14);
        textArea.setFont(font);

        JScrollPane scrollPane = new JScrollPane(textArea);

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(scrollPane, BorderLayout.CENTER);

        add(panel);

        setLocationRelativeTo(null); // Center the frame on the screen

        // Timer for text display updates
        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                loadTextFromFile();
            }
        }, 0, delay);

        // Watch for changes in the file
        watchFileChanges();
    }

    private void watchFileChanges() {
        Path path = FileSystems.getDefault().getPath("System_files");
        try {
            WatchService watchService = FileSystems.getDefault().newWatchService();
            path.register(watchService, StandardWatchEventKinds.ENTRY_MODIFY);

            TimerTask watchTask = new TimerTask() {
                @Override
                public void run() {
                    WatchKey key = watchService.poll();
                    if (key != null) {
                        for (WatchEvent<?> event : key.pollEvents()) {
                            if (event.kind() == StandardWatchEventKinds.ENTRY_MODIFY) {
                                // File has been modified, reload text
                                loadTextFromFile();
                            }
                        }
                        key.reset();
                    }
                }
            };

            Timer watchTimer = new Timer();
            watchTimer.scheduleAtFixedRate(watchTask, 0, 1000);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void loadTextFromFile() {
        try (BufferedReader bufferedReader = new BufferedReader(new FileReader(filePath))) {
            StringBuilder content = new StringBuilder();
            String line;

            while ((line = bufferedReader.readLine()) != null) {
                content.append(line).append("\n");
            }

            SwingUtilities.invokeLater(() -> {
                textArea.setText(content.toString());
                textArea.setCaretPosition(textArea.getDocument().getLength()); // Auto-scroll to the bottom

                // Check if the loaded text is "exit" and close the window
                if (content.toString().trim().equalsIgnoreCase("exit")) {
                    dispose();
                }
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Updater_main().setVisible(true));
    }
}
